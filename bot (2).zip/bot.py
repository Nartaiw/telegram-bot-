import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.methods import DeleteWebhook
from aiogram.types import Message
from openai import OpenAI


TOKEN = '8222101274:AAF824HK5P3JdQIR9lDZKSlXQVFsl15vJ9I' 

logging.basicConfig(level=logging.INFO)
bot = Bot(TOKEN)
dp = Dispatcher()


# ⁡⁢⁣⁡⁢⁣⁣ОБРАБОТЧИК КОМАНДЫ СТАРТ⁡⁡
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    await message.answer('Привет! Я бот с подключенной нейросетью, отправь свой запрос', parse_mode = 'HTML')


# ⁡⁢⁣⁣ОБРАБОТЧИК ЛЮБОГО ТЕКСТОВОГО СООБЩЕНИЯ⁡
@dp.message(lambda message: message.text)
async def filter_messages(message: Message):
    client = OpenAI(
    base_url = "https://api.langdock.com/openai/eu/v1",
    api_key = "sk-Jmzn_Ure_U4v4hR1gi5VT8l_XEkaFefQYUllZDmoXZ8LIW7zRJC8vDe8-XA8Yv7fQxG69o1ydDY2yNinlBrCUg" # ⁡⁢⁣⁣ПОМЕНЯЙТЕ ТОКЕН ИИ НА ВАШ⁡
    )

    completion = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[
        {"role": "user", "content": message.text}
    ]
    )
    text = completion.choices[0].message.content

    await message.answer(text, parse_mode = "Markdown")
  
@dp.message(lambda message: message.photo)
async def handle_photo(message: types.Message):
    photo = message.photo[-1]
    file = await bot.get_file(photo.file_id)
    file_path = file.file_path
    file_url = f'https://api.telegram.org/file/bot{TOKEN}/{file_path}'


async def main():
    await bot(DeleteWebhook(drop_pending_updates=True))
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())